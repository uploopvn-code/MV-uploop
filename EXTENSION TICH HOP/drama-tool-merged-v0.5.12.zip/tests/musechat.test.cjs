const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const source = fs.readFileSync(require('node:path').join(__dirname, '../background.js'), 'utf8');
function extract(name, next) { return source.slice(source.indexOf(`async function ${name}`), source.indexOf(next, source.indexOf(`async function ${name}`))); }
function fixture({ preview = true, sendWorks = true, hiddenPicker = true } = {}) {
  let now = 0, clicked = 0, attached = false, text = '', messages = [];
  class Input { set value(v) { this._value = v; } get value() { return this._value || ''; } }
  const input = new Input();
  Object.assign(input, { tagName: 'TEXTAREA', focus() {}, closest() { return scope; }, dispatchEvent() {} });
  const button = { disabled: false, getAttribute: x => x === 'type' ? 'submit' : null, querySelector: () => null,
    click() { clicked++; assert.ok(context.window.__dramaMuseChatActiveJob.sentAt > 0); if (sendWorks) { text = input.value; input.value = ''; } } };
  const picker = { disabled: false, accept: 'image/*', multiple: true, hidden: hiddenPicker,
    dispatchEvent(event) { if (event.type === 'change') attached = true; } };
  const scope = { contains: el => el === picker, get innerText() { return text; },
    querySelectorAll(selector) {
      if (selector === 'img') return attached && preview ? [{ src: 'blob:reference' }] : [];
      if (selector.includes('progressbar')) return [];
      if (selector.includes('button')) return [button];
      return messages;
    } };
  const ui = { composer: () => input, value: el => el.value, scope: () => scope, visible: el => !el.hidden, label: () => 'Send' };
  const context = { window: { __dramaMuseChatUi: ui }, document: { querySelectorAll: () => [picker] },
    Date: { now: () => ++now }, setTimeout: (fn, ms) => { now += ms; fn(); },
    DataTransfer: class { constructor() { this.files = []; this.items = { add: f => this.files.push(f) }; } },
    File: class { constructor(bytes, name, options) { Object.assign(this, { bytes, name, ...options }); } },
    Event: class { constructor(type) { this.type = type; } }, InputEvent: class {},
    HTMLTextAreaElement: Input, HTMLInputElement: Input, Uint8Array, atob };
  vm.createContext(context);
  vm.runInContext(extract('museChatDriveUi', '// Download the video inside the page') + extract('museChatIsNewChat', '// Click the'), context);
  return { context, picker, input, run: () => context.museChatDriveUi({ queueId: 'job', prompt: 'Create video', images: [{ base64: 'YQ==', filename: 'ref.png', mime: 'image/png' }] }),
    clicked: () => clicked, setMessages: value => { messages = value; }, setText: value => { text = value; } };
}
test('hidden file input uploads reference and sends once with capture armed', async () => {
  const f = fixture(); assert.equal((await f.run()).ok, true); assert.equal(f.picker.files.length, 1); assert.equal(f.clicked(), 1);
});
test('no attachment preview prevents prompt submission', async () => {
  const f = fixture({ preview: false }); const result = await f.run(); assert.equal(result.ok, false); assert.match(result.detail, /ảnh đính kèm/); assert.equal(f.input.value, 'Create video'); assert.equal(f.clicked(), 0);
});
test('prompt remaining in composer is not a successful send and is not replayed', async () => {
  const f = fixture({ sendWorks: false }); const result = await f.run(); assert.equal(result.ok, false); assert.match(result.detail, /không tự gửi lại/); assert.equal(f.clicked(), 1);
});
test('welcome text does not count as old messages; real messages and drafts do', async () => {
  const f = fixture(); f.setText('Welcome '.repeat(100)); assert.equal(await f.context.museChatIsNewChat(), true);
  f.setMessages([{ contains: () => false }]); assert.equal(await f.context.museChatIsNewChat(), false);
  f.setMessages([]); f.input.value = 'draft'; assert.equal(await f.context.museChatIsNewChat(), false);
});
test('reference download failure keeps owned tab open and never calls send', async () => {
  let removed = false, sent = false, error = '';
  const context = { trackJob: () => ({}), setInterval: () => 1, clearInterval() {}, heartbeat() {},
    chrome: { tabs: { query: async () => [], create: async () => ({ id: 42 }), update: async () => {}, remove: async () => { removed = true; } } },
    MUSECHAT_HOME_URL: 'https://muse.ai/', console: { log() {} }, report() {}, ensureMuseChatHook: async () => {},
    execMain: async (_id, fn) => { if (fn.name === 'museChatDriveUi') sent = true; return fn.name === 'museChatIsNewChat' ? true : { ok: true }; },
    museChatWaitReady() {}, museChatClickNewChat() {}, museChatIsNewChat() {}, museChatDriveUi() {},
    sleep: async () => {}, clearMuseChatActive: async () => {}, downloadRef: async () => { throw new Error('missing image'); },
    fail: async (_job, message) => { error = message; }, active: new Map(), anyRunning: () => false };
  vm.createContext(context); vm.runInContext(extract('startMuseChatJob', 'const clearMuseChatActive'), context);
  await context.startMuseChatJob({ id: 'job', payload: { references: [{ asset: {} }] } });
  assert.equal(removed, false); assert.equal(sent, false); assert.match(error, /missing image/);
});

test('contenteditable falls back when execCommand cannot insert text', async () => {
  const f = fixture();
  f.input.isContentEditable = true;
  Object.defineProperty(f.input, 'textContent', { get() { return this.value; }, set(value) { this.value = value; } });
  f.input.dispatchEvent = () => true;
  f.context.document.createRange = () => ({ selectNodeContents() {} });
  f.context.document.execCommand = () => false;
  f.context.window.getSelection = () => ({ removeAllRanges() {}, addRange() {} });
  assert.equal((await f.run()).ok, true);
  assert.equal(f.clicked(), 1);
});
test('editor reset during rendering is refilled before sending', async () => {
  const f = fixture();
  let edits = 0;
  f.input.dispatchEvent = () => { if (++edits === 1) f.input.value = ''; };
  assert.equal((await f.run()).ok, true);
  assert.ok(edits >= 4);
  assert.equal(f.clicked(), 1);
});
