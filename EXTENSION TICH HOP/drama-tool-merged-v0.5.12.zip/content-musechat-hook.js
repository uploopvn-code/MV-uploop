// Drama Tool Muse-Chat worker — page-world hook (runs in MAIN world at document_start on
// muse.ai). It watches the web chat for the finished video of the active job and reports it back.
//
// The service worker marks a job active by setting
//   window.__dramaMuseChatActiveJob = { queueId, sentAt }
// sentAt = timestamp (ms) of when the prompt was actually sent. Only videos that APPEAR
// AFTER sentAt are candidates — sample/promo/UI videos already on the page are ignored.
// While a job is active, the best candidate so far is stashed in
//   window.__dramaMuseChatCaptured = { queueId, videoUrl }
// and a generation-time failure in
//   window.__dramaMuseChatError = { queueId, detail }
// The service worker polls those globals back. No chrome.* here — MAIN world has none.
//
// Scoring (higher wins; ties go to the later observation):
//   +2  rendered in the conversation DOM (<video>/<source>/<a>) instead of only seen in a
//       network response
//   +2  prominent player (rendered >= 300px wide or >= 200px tall)
//   -1  (rejected) inside nav/header/aside/footer UI chrome, or a tiny (<120px) animation
// Rationale: the generated clip is the prominent video rendered in the conversation — not a
// thumbnail, avatar animation, or sample video from the page chrome.
//
// DESIGN NOTE (per requirement): every command runs in its OWN tab with NO tab reuse and NO
// concurrency cap, so one tab == one job. Captures are still keyed by queueId as a safety net.

(function () {
  if (window.__dramaMuseChatHookInstalled) return;
  window.__dramaMuseChatHookInstalled = true;
  window.__dramaMuseChatActiveJob = window.__dramaMuseChatActiveJob || null;
  window.__dramaMuseChatCaptured = window.__dramaMuseChatCaptured || null;
  window.__dramaMuseChatError = window.__dramaMuseChatError || null;

  // Shared DOM targeting for readiness, fresh-chat checks, uploads and sending.
  window.__dramaMuseChatUi = {
    visible(el) {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 0 && rect.height > 0 && style.display !== 'none' && style.visibility !== 'hidden';
    },
    label(el) { return [el.getAttribute('aria-label'), el.getAttribute('title'), el.getAttribute('placeholder'), el.innerText].filter(Boolean).join(' '); },
    value(el) { return el.isContentEditable ? (el.innerText || el.textContent || '') : el.value || ''; },
    composer() {
      const ui = this;
      const candidates = [...document.querySelectorAll('textarea, [contenteditable="true"], [contenteditable=""], [contenteditable="plaintext-only"], [role="textbox"], input[type="text"]')]
        .filter(el => (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT' || el.isContentEditable) && ui.visible(el) && !el.disabled && !el.readOnly && !/search|tìm kiếm/i.test(ui.label(el)));
      candidates.sort((a, b) => {
        const score = el => (el.tagName === 'TEXTAREA' || el.isContentEditable ? 20 : 0) +
          (/message|chat|ask|prompt|nhắn/i.test(ui.label(el)) ? 40 : 0) +
          (el.closest('[role="dialog"]') ? 80 : 0) + el.getBoundingClientRect().top / Math.max(1, innerHeight);
        return score(b) - score(a);
      });
      return candidates[0] || null;
    },
    scope(input) {
      return input.closest('[role="dialog"], [data-chat-id], .chat-container, .chat-panel, .side-chat, section, main, aside') || input.closest('form')?.parentElement || input.parentElement;
    },
  };

  let lastQueueId = '';
  let best = null; // { url, score, at } — best video candidate for the current job

  function activeJob() {
    const j = window.__dramaMuseChatActiveJob;
    if (!j || !j.queueId) return null;
    if (j.queueId !== lastQueueId) {
      lastQueueId = j.queueId;
      best = null;
    }
    return j;
  }

  function cleanUrl(u) {
    return String(u || '')
      .replace(/\\u0026/g, '&')
      .trim();
  }

  function findVideoUrl(value) {
    if (!value) return '';
    const text = typeof value === 'string' ? value : JSON.stringify(value || {});
    let m = text.match(/https?:\/\/[^\s"'\\]+\.(?:mp4|webm)(?:\?[^\s"'\\]*)?/i);
    if (m) return cleanUrl(m[0]);
    m = text.match(/blob:https?:\/\/[^\s"'\\]+/i);
    if (m) return cleanUrl(m[0]);
    return '';
  }

  function inUiChrome(el) {
    try {
      // Muse can render the conversation in an aside (Side chat).
      const ui = window.__dramaMuseChatUi;
      const composer = ui && ui.composer();
      if (composer && ui.scope(composer).contains(el)) return false;
      return !!el.closest(
        'nav, header, aside, footer, [role="navigation"], [role="banner"], [role="complementary"]',
      );
    } catch (_) {
      return false;
    }
  }

  // Score a candidate video. Negative = reject outright.
  function scoreCandidate(url, el) {
    if (!url) return -1;
    if (!el) return 0; // seen only in a network response: neutral
    const target = el instanceof HTMLSourceElement && el.parentElement ? el.parentElement : el;
    if (inUiChrome(target)) return -1;
    let rect = null;
    try {
      rect = target.getBoundingClientRect();
    } catch (_) {}
    if (rect && rect.width > 0 && rect.height > 0 && rect.width < 120 && rect.height < 120)
      return -1; // tiny UI animation, not the generated clip
    let s = 2; // rendered in the conversation DOM
    if (rect && (rect.width >= 300 || rect.height >= 200)) s += 2; // prominent player
    return s;
  }

  function capture(url, el) {
    const job = activeJob();
    if (!job) return;
    // Only videos that appear AFTER the prompt was actually sent count.
    if (!job.sentAt || Date.now() < job.sentAt) return;
    const score = scoreCandidate(url, el);
    if (score < 0) return;
    const at = Date.now();
    if (!best || score > best.score || (score === best.score && at >= best.at)) {
      best = { url, score, at };
      window.__dramaMuseChatCaptured = { queueId: job.queueId, videoUrl: url };
      console.log('[Drama Tool · Muse Chat] 🎬 Video (score ' + score + '):', url.slice(0, 90));
    }
  }

  function fail(detail) {
    const job = activeJob();
    if (!job) return;
    window.__dramaMuseChatError = { queueId: job.queueId, detail: String(detail).slice(0, 300) };
    console.log('[Drama Tool · Muse Chat] ⚠️ Lỗi:', detail);
  }

  // 1. Network responses: the chat backend may return the video file URL in JSON.
  const RELEVANT = /message|chat|conversation|media|video|generat|attach|upload/i;
  function inspectResponse(url, ok, status, text) {
    const job = activeJob();
    if (!job || !RELEVANT.test(url)) return;
    if (!ok && /message|conversation|chat/i.test(url)) {
      fail('Muse chat báo lỗi HTTP ' + status + ': ' + String(text || '').slice(0, 120));
      return;
    }
    const v = findVideoUrl(text);
    if (v) capture(v, null);
  }

  const origFetch = window.fetch;
  window.fetch = async function (...args) {
    const resp = await origFetch.apply(this, args);
    try {
      const req = typeof Request !== 'undefined' && args[0] instanceof Request ? args[0] : null;
      const url =
        typeof args[0] === 'string' ? args[0] : req ? req.url : args[0] && args[0].url ? args[0] : '';
      if (activeJob() && RELEVANT.test(url)) {
        resp
          .clone()
          .text()
          .then(t => inspectResponse(url, resp.ok, resp.status, t))
          .catch(() => {});
      }
    } catch (_) {}
    return resp;
  };

  const origOpen = XMLHttpRequest.prototype.open;
  const origSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (method, url, ...rest) {
    this.__mcUrl = url;
    return origOpen.apply(this, [method, url, ...rest]);
  };
  XMLHttpRequest.prototype.send = function (body) {
    const url = this.__mcUrl || '';
    if (RELEVANT.test(url)) {
      this.addEventListener(
        'loadend',
        () => {
          try {
            if (activeJob())
              inspectResponse(
                url,
                !(this.status >= 400),
                this.status,
                String(this.responseText || ''),
              );
          } catch (_) {}
        },
        { once: true },
      );
    }
    return origSend.apply(this, [body]);
  };

  // 2. DOM watch: the assistant's reply renders the video as <video>/<source> or a link.
  // Only elements that appear AFTER the prompt was sent are candidates (see capture()).
  function scanNode(root) {
    const job = activeJob();
    if (!job) return;
    const els = [];
    try {
      if (root instanceof HTMLVideoElement) els.push(root);
      if (root.querySelectorAll) {
        els.push(...root.querySelectorAll('video'));
        els.push(...root.querySelectorAll('a[href]'));
        els.push(...root.querySelectorAll('source[src]'));
      }
    } catch (_) {}
    for (const el of els) {
      const u = cleanUrl(
        el.currentSrc || el.src || el.getAttribute('src') || el.getAttribute('href') || '',
      );
      if (!u) continue;
      if (/\.mp4(\?|$)/i.test(u) || /\.webm(\?|$)/i.test(u) || /^blob:/i.test(u)) {
        capture(u, el);
      }
    }
  }

  const observer = new MutationObserver(muts => {
    if (!activeJob()) return;
    for (const m of muts) {
      if (m.type === 'attributes' && m.target && m.target.nodeType === 1) {
        scanNode(m.target);
      } else {
        for (const n of m.addedNodes) {
          if (n.nodeType === 1) scanNode(n);
        }
      }
    }
  });
  try {
    observer.observe(document.documentElement || document, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ['src', 'href'],
    });
  } catch (_) {}

  console.log('[Drama Tool · Muse Chat] Hook đã sẵn sàng.');
})();
