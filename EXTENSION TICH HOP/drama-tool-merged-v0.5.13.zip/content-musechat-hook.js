// Muse job observer. Captures only this job's new video, never attachment blobs or page demos.
(function () {
  if (window.__dramaMuseChatHookInstalled) return;
  window.__dramaMuseChatHookInstalled = true;
  const KEY = '__dramaMuseChatJob_v13';
  const ui = () => window.__dramaMuseChatUi;
  let baseline = new Set(), best = null;
  const norm = s => String(s || '').replace(/\s+/g, ' ').trim();
  const job = () => window.__dramaMuseChatActiveJob;
  const save = () => { try { sessionStorage.setItem(KEY, JSON.stringify({ ...job(), baseline: [...baseline] })); } catch (_) {} };
  const urlOf = el => el.currentSrc || el.src || el.href || el.getAttribute('src') || el.getAttribute('href') || '';
  const media = root => [...root.querySelectorAll('video, video source, a[href]')];
  function arm(queueId, prompt) {
    baseline = new Set(media(document).map(urlOf).filter(Boolean)); best = null;
    window.__dramaMuseChatCaptured = null; window.__dramaMuseChatError = null;
    window.__dramaMuseChatActiveJob = { queueId, prompt, sentAt: Date.now(), confirmed: false, requestStarted: false };
    save();
  }
  function confirm() { if (job()) { job().confirmed = true; save(); scan(); } }
  function clear() { window.__dramaMuseChatActiveJob = null; try { sessionStorage.removeItem(KEY); } catch (_) {} }
  window.__dramaMuseChatArm = arm;
  window.__dramaMuseChatConfirm = confirm;
  window.__dramaMuseChatClear = clear;
  try {
    const restored = JSON.parse(sessionStorage.getItem(KEY) || 'null');
    if (restored?.queueId && restored.sentAt && Date.now() - restored.sentAt < 20 * 60 * 1000) {
      baseline = new Set(restored.baseline || []); delete restored.baseline;
      window.__dramaMuseChatActiveJob = restored;
    }
  } catch (_) {}
  function capture(rawUrl, score, qid) {
    const active = job();
    if (!active?.confirmed || active.queueId !== qid || !rawUrl) return;
    let url;
    try { url = new URL(rawUrl.replace(/\\u0026/g, '&'), location.href).href; } catch (_) { return; }
    if (!/^(https?:|blob:)/.test(url) || /\.(m3u8|mpd)(?:[?#]|$)/i.test(url) || baseline.has(url)) return;
    if (best && best.score > score) return;
    if (best?.url === url && best.score === score) return;
    best = { url, score };
    window.__dramaMuseChatCaptured = { queueId: qid, videoUrl: url, score };
  }
  function scan() {
    const active = job(), input = ui()?.composer();
    if (!active?.sentAt || !input) return;
    if (!active.confirmed && !norm(ui().value(input)) && ui().hasMessage(input, active.prompt)) {
      active.confirmed = true; save();
    }
    if (!active.confirmed) return;
    const region = ui().scope(input);
    for (const el of media(region)) {
      if (el.closest('[data-message-author-role="user"], [data-role="user"]')) continue;
      const isPlayer = el.tagName === 'VIDEO' || el.tagName === 'SOURCE';
      const url = urlOf(el);
      // A <video> URL need not have an extension. A generic blob link can be an image.
      if (!isPlayer && !/\.(mp4|webm)(?:[?#]|$)/i.test(url) && !/^video\//i.test(el.type || '')) continue;
      const player = el.tagName === 'SOURCE' ? el.parentElement : el;
      if (isPlayer && player.error) continue;
      capture(url, /^blob:/.test(url) ? 2 : isPlayer ? 4 : 5, active.queueId);
    }
  }
  window.__dramaMuseChatPoll = scan;
  const RELEVANT = /message|chat|conversation|generat|render|task/i;
  function context(url, method, body) {
    const active = job();
    if (!active?.sentAt || !RELEVANT.test(url) || !/POST|PUT|PATCH/i.test(method)) return null;
    let text = typeof body === 'string' ? body : '';
    try { text = JSON.stringify(JSON.parse(text)); } catch (_) {}
    const needle = String(active.prompt || '');
    // Match the submitted prompt, not unrelated uploads, telemetry, history or polling.
    if (!needle || (!norm(text).includes(norm(needle)) && !text.includes(JSON.stringify(needle).slice(1, -1)))) return null;
    active.requestStarted = true; save();
    return { queueId: active.queueId, sentAt: active.sentAt };
  }
  function same(ctx) { return ctx && job()?.queueId === ctx.queueId && job()?.sentAt === ctx.sentAt; }
  function response(ctx, ok, status) {
    if (!same(ctx)) return;
    if (!ok) {
      window.__dramaMuseChatError = { queueId: ctx.queueId, detail: 'Muse từ chối gửi prompt (HTTP ' + status + ').' };
    } else confirm();
  }
  function inspect(ctx, text) {
    if (!same(ctx) || !job().confirmed) return;
    try {
      const data = JSON.parse(text);
      if (data && (data.error || data.success === false)) {
        const detail = typeof data.error === 'string' ? data.error : data.error?.message || data.message || 'Không tạo được video';
        window.__dramaMuseChatError = { queueId: ctx.queueId, detail: String(detail).slice(0, 300) };
        return;
      }
    } catch (_) {}
    const decoded = String(text).replace(/\\\//g, '/').replace(/\\u0026/g, '&');
    for (const match of decoded.matchAll(/https?:\/\/[^\s"'<>\\]+\.(?:mp4|webm)(?:\?[^\s"'<>\\]*)?/gi)) capture(match[0], 1, ctx.queueId);
  }
  const originalFetch = window.fetch;
  window.fetch = async function (...args) {
    const request = typeof Request !== 'undefined' && args[0] instanceof Request ? args[0] : null;
    const url = String(request?.url || args[0]?.url || args[0] || '');
    const method = args[1]?.method || request?.method || 'GET';
    let body = args[1]?.body;
    // Clone only text request bodies of active chat writes; do not consume the site's body.
    if (body == null && request && job()?.sentAt && RELEVANT.test(url) && /POST|PUT|PATCH/i.test(method)) {
      try { body = await request.clone().text(); } catch (_) {}
    }
    const ctx = context(url, method, body);
    try {
      const result = await originalFetch.apply(this, args);
      response(ctx, result.ok, result.status);
      const type = result.headers.get('content-type') || '';
      if (ctx && result.ok && /json|text/.test(type)) result.clone().text().then(text => inspect(ctx, text)).catch(() => {});
      return result;
    } catch (error) {
      // A dropped response is ambiguous; never replay the prompt automatically.
      if (same(ctx)) window.__dramaMuseChatError = { queueId: ctx.queueId, detail: 'Mất kết nối khi gửi prompt; kiểm tra chat trước khi chạy lại.' };
      throw error;
    }
  };
  const open = XMLHttpRequest.prototype.open, send = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (method, url, ...rest) {
    this.__dramaRequest = { method, url: String(url) }; return open.call(this, method, url, ...rest);
  };
  XMLHttpRequest.prototype.send = function (body) {
    const meta = this.__dramaRequest || {}, ctx = context(meta.url || '', meta.method || '', body);
    if (ctx) this.addEventListener('loadend', () => {
      response(ctx, this.status >= 200 && this.status < 400, this.status);
      try { inspect(ctx, this.responseType === 'json' ? JSON.stringify(this.response) : this.responseText); } catch (_) {}
    }, { once: true });
    return send.call(this, body);
  };
  let scanPending = false;
  const schedule = () => {
    if (!job()?.sentAt || scanPending) return;
    scanPending = true; setTimeout(() => { scanPending = false; scan(); }, 150);
  };
  new MutationObserver(schedule).observe(document.documentElement || document, {
    subtree: true, childList: true, attributes: true, attributeFilter: ['src', 'href'],
  });
  document.addEventListener('loadeddata', schedule, true);
  document.addEventListener('canplay', schedule, true);
})();
